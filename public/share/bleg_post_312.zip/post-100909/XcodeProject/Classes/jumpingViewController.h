#import <UIKit/UIKit.h>

@interface jumpingViewController : UIViewController {
	UIImageView *player;
}

@property (nonatomic, retain) UIImageView *player;

@end

